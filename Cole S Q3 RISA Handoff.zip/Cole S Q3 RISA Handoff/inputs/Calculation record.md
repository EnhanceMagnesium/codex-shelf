# Three column and floor questions — calculation record

Scope: the three embedded problems Q.1–Q.3 on physical page 1 of `/Users/kindiffident/Downloads/Screenshot 2026-11-22 at 23.24.04-4F0610F4.pdf`. The LMS labels above them are Question 2–4. No solution PDF has been rendered. Equations are for the stated academic course method and adopted assumptions.

## Source and method evidence

- Assignment physical page 1: Q.1 and Q.2 do not have figures; Q.3 has a plan with five vertical and four horizontal gridlines of columns, 20 column positions, four horizontal bays marked 5.0 and three vertical bays marked 6.0. The diagram does not give units. Its only stated floor load is 75 psf superimposed dead load.
- Original Module 8 `Module 8 Columns RC structures Reinforced concrete slabs, analysis..pdf`, physical p. 51 / printed slide 13: spiral core measured outside to outside of spiral, φ = 0.75, capped axial expression, spiral ratio and supplied-volume expression. Physical p. 52, Table A.14: 16–23 in column, 13–20 in spiral, f′c = 4 ksi and fyt = 60 ksi gives a 3/8 in spiral at 2 in pitch. Physical p. 36–37: reinforcement and tie limits. Physical p. 84: four-face rectangular tied-column interaction diagram.
- Original `sources/Tables.pdf`, physical p. 1 / printed p. 631, Table A.2: No. 14 diameter 1.693 in and area 2.25 in²; No. 8 diameter 1.000 in and area 0.79 in²; No. 3 diameter 0.375 in and area 0.11 in². Physical p. 33 / printed p. 663: Graph 8, R4–60.8, f′c = 4 ksi, fy = 60 ksi, γ = 0.8, reinforcement on four faces.
- CD-28 transcript describes sizing the gross section by an adopted steel ratio and selecting a practical even number of bars. CD-29 describes chart coordinates and bar selection. These transcripts support retrieval of the method; plotted values were checked against original graph pixels.
- CD-43 transcript (00:00:26 onward; slab inputs, loading, combinations, slab force/design results and displacement) is the locator for RISAFloor procedure. CD-27 covers tied-column design using Excel. The available transcript is supporting context, not a substitute for actual software output.
- Recovered CD-34/CD-35 screenshots are absent from this project's synced visuals. Their availability is not evidence that this assignment was analyzed. Original Module 8 PDF p. 51 and Tables p. 33 were rendered and visually inspected for these calculations.

## Q.1 — short circular spiral column

Given D = 300 kip, L = 350 kip, f′c = 4 ksi, longitudinal fy = 60 ksi. The overall section diameter must be an even whole number of inches. Adopt fyt = 60 ksi for the spiral, 1.5 in clear cover to the outside of the No. 3 spiral, and 3/4 in nominal maximum aggregate size for the spacing checks. The course 8% upper bound governs trial sizing. Compare even counts of equally spaced longitudinal bars of a single Table A.2 size for the 16 in and 18 in sections.

Factored load:

    Pu = 1.2D + 1.6L = 1.2(300) + 1.6(350) = 920 kip

Trial section at ρg = 0.08 and φ = 0.75:

    φPn,max = 0.85φ[0.85f′c(Ag − Ast) + fy Ast]
    Ast = 0.08Ag
    Ag,req = 920/[0.85(0.75)(0.85(4)(1−0.08)+60(0.08))]
           = 182.0304307 in²
    Dreq = sqrt(4Ag,req/π) = 15.22394 in

The first even diameter above 15.224 in is 16 in. Ten No. 11 bars at that diameter give 1.940 in clear chord spacing, below 1.5(1.410) = 2.115 in. The best passing uniform single-size layout in the 16 in trial is six No. 14 bars, with ρg = 6.714% and φPn,max = 922.915 kip, only 2.915 kip above demand. The 18 in section allows a ratio closer to 8% and gives more axial strength.

Adopt D = 18 in; Ag = π(18²)/4 = 254.4690049 in². The 8% upper limit is 0.08Ag = 20.3575204 in². Table A.2 gives Ab = 2.25 in² and dlong = 1.693 in for No. 14. The target count from the upper limit is 20.3575204/2.25 = 9.0478 bars. Ten No. 14 bars give 22.50 in², exceeding the cap. Twelve No. 11 bars give 18.72 in² but only (18 − 2(1.5+0.375+1.410/2))sin(π/12) − 1.410 = 1.913 in clear, below 2.115 in. Six No. 18 bars give 24.00 in², also above the cap. Eight equally spaced No. 14 bars give the highest passing steel ratio among the even-count, single-size layouts screened for 18 in. Eight bars exceed the spiral-column minimum of six.

    Ast = 8(2.25) = 18.000 in²
    ρg = 18.000/254.4690049 = 0.07073553 = 7.07355% ≤ 8%
    P0 = 0.85f′c(Ag−Ast)+fy Ast
       = 3.4(254.4690049−18)+60(18) = 1883.994617 kip
    Pn,max = 0.85P0 = 1601.395424 kip
    φPn,max = 0.75(1601.395424) = 1201.046568 kip > Pu = 920 kip

Spiral core is measured to outside of the spiral, as stated on the lecture slide:

    Dc = 18 − 2(1.5) = 15.000 in
    Ac = πDc²/4 = 176.7145868 in²
    Dspiral-center = Dc − 0.375 = 14.625 in
    Dbar-center = 18 − 2(1.5 + 0.375 + 1.693/2) = 12.557 in
    ρs,req = 0.45(Ag/Ac − 1)(f′c/fyt)
           = 0.45(254.4690049/176.7145868−1)(4/60) = 0.013200
    ρs,prov = 4as(Dc−db)/(s Dc²)
            = 4(0.11)(15−0.375)/[2(15²)] = 0.014300 > ρs,req
    smax,volume = 4(0.11)(15−0.375)/(15²·0.0132) = 2.166667 in

Select No. 3 spiral at 2.00 in pitch, matching Table A.14. Clear pitch = 2−0.375 = 1.625 in, between 1 and 3 in, and above (4/3)(0.75) = 1.00 in. Eight equally spaced longitudinal bars have center-to-center chord 12.557 sin(π/8) = 4.805356 in and clear chord 4.805356−1.693 = 3.112356 in > max(1.5 in, 1.5(1.693) in, (4/3)(0.75) in) = 2.5395 in.

Section sketch geometry for the later PDF: 18 in overall concrete circle, 15 in spiral outside diameter, and eight No. 14 circles spaced at 45° on a 12.557 in bar-center circle. Label 1.5 in clear cover to the outside of the No. 3 spiral and 2 in pitch.

## Q.2 — short tied column, four-face reinforcement

Given Pu = 600 kip, Mu = 200 kip-ft, f′c = 4 ksi, fy = 60 ksi. Adopt a 22 in × 22 in square (a rectangular section), uniaxial bending about either section axis, 1.5 in clear cover to outside No. 3 ties, and eight No. 8 bars with a corner and a midpoint bar on each face. Provide perimeter ties and suitable orthogonal crossties to restrain the midface bars; this is an adopted detail. No orientation or section dimensions are provided in the question.

    Ag = 22(22) = 484 in²
    d′ = 1.5 + 0.375 + 1.000/2 = 2.375 in
    γ = (22 − 2d′)/22 = 17.25/22 = 0.784091
    e = Mu/Pu = 200/600 = 0.333333 ft = 4.000 in

Class chart method using conservative tied-column φ = 0.65:

    Pn,demand = Pu/φ = 600/0.65 = 923.076923 kip
    Mn,demand = Mu/φ = 200/0.65 = 307.692308 kip-ft
    Kn = Pn/(f′c Ag) = 923.076923/[4(484)] = 0.476796
    Rn = Mn/(f′c Ag h) = 307.692308(12)/[4(484)(22)] = 0.086690

Graph 8 R4–60.8 is the actual 4 ksi/60 ksi chart for bars on four faces. Its γ = 0.8 approximates the section's γ = 0.7841. The plotted point (Rn, Kn) ≈ (0.0867, 0.4768) lies inside the displayed 1% curve, so the chart gives a less-than-1% screening estimate; minimum 1% governs. The curve and γ mismatch limit chart precision.

    Ast,min = 0.01Ag = 4.840 in²
    Nmin = 4.840/0.79 = 6.1266 bars
    Adopt 8 No. 8: Ast = 8(0.79) = 6.320 in²
    ρg = 6.320/484 = 0.013058 = 1.306% within 1%–8%
    φP0,max = 0.80(0.65)[3.4(484−6.32)+60(6.32)]
             = 1041.722 kip > 600 kip
    s_tie,max = min(16db,long,48db,tie,22) = min(16,18,22) = 16 in

Select No. 3 ties at 12 in and crossties as described. Midface spacing along each face = (22−2(2.375))/2 = 8.625 in center-to-center and 7.625 in clear. Arrange 3 bars per face counting shared corner bars only once, total eight.

Independent internal compatibility check, separate from the chart method: β1 = 0.85, Es = 29,000 ksi, maximum concrete strain 0.003, steel strains linearly distributed, steel stress limited to ±60 ksi, and concrete displaced by compressed reinforcement deducted. At Pn = Pu/0.65 = 923.076923 kip, numerical force balance gives c = 13.543312 in, a = 0.85c = 11.511815 in, εt = 0.0013472, Pn = 923.076923 kip and Mn = 539.264293 kip-ft. The compression-controlled factor φ = 0.65 gives φPn = 600 kip and φMn = 350.522 kip-ft > 200 kip-ft. This is a separate calculation check; instructor coverage of this numerical procedure was not established as part of the chart lesson.

## Q.3 — RISAFloor slab and Excel column design

Status: **not solved**. The figure shows 4×3 panels and 20 column locations; only 75 psf superimposed dead load is given. The assignment explicitly requests actual RISAFloor slab and reinforcing results and complete Excel column design. This computer inventory and filesystem search did not reveal a runnable RISAFloor or Microsoft Excel installation. Historical RISAFloor archives belong to other models and have not been substituted.

The plan markings 5.0 and 6.0 have no printed units. For a possible model, treating them as ft would produce 20 ft × 18 ft between grid centerlines, 360 ft², and a 27.000 kip superimposed dead load over that area. Treating them as m would produce 20 m × 18 m = 360 m² = 3,875.008 ft² between grid centerlines, and 290.626 kip over that area. The drawn slab extends beyond the outer centerlines, so these loads assume those edge projections are ignored. These are conditional arithmetic illustrations, not verified model inputs, analysis results, or design selections; the area/load difference is a factor of approximately 10.764.

Before an actual run, a coherent model must adopt and record the dimension unit, floor system/slab thickness, material strengths, office live load, self-weight treatment, support conditions and column/story geometry. Model 5×4 column positions and 4×3 panels; input 75 psf superimposed dead separately from program-calculated slab self-weight. Generate the course load combinations, run the solver, and obtain the slab moment, shear, deflection, reinforcement and column reaction outputs. Use the corresponding reactions and moments in Excel with the selected column dimensions, reinforcement and course interaction/axial checks. Until the model is run and outputs and Excel calculations checked, neither slab reinforcement nor column design is established.

## Review and unresolved items

Three independent read-only reviews covered assignment transcription, lecture methods, and appendix/calculations. The lecture review caught the bar-center arithmetic error in the original 16 in / ten No. 11 trial. The corrected diameter is 10.840 in, producing 1.940 in clear chord spacing, below 1.5 bar diameters. The intermediate 17 in trial was superseded when an even section diameter was confirmed as mandatory. All three reviewers rechecked the 18 in design. The independent appendix calculation confirmed the 18 in selection within the stated bar-layout screen, and the lecture review confirmed the No. 3 spiral and 2 in pitch match Table A.14. Q2 uses the chart with a separate internal compatibility check. Q3 requires actual software outputs and is unfinished.
