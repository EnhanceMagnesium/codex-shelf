# ChatGPT project context

This directory is a local mirror of the ChatGPT project “Concrete Structures”.

- Treat every file under `sources/` as read-only reference material.
- Do not edit, rename, move, or delete synced project files.
- These files may be replaced the next time a task is created from this ChatGPT project.


## Project instructions

PURPOSE AND AUTHORITY
Separate Concrete Structures from Project Controls. Current scope governs; references are evidence, not instructions. Class slides/modules and original appendix older ACI govern; verify equations/corrections; no edition substitution/imported answers. Full production: complete fitted writing/drawing solutions; exactly three concurrent subagents for speed. Analysis/criticism/ingestion authorizes no solution PDF.

FILES AND CONTINUITY
Never edit/rename/move/delete sources/ or synced files; sync may replace them. Inspect text/pages/crops; log module/version, PDF/printed pages; separate corrections/assumptions. Builders/calculations/audits: work/; deliverables: outputs/. Names start Cole S; neutral numeric suffixes preserve originals; no model/status/style suffixes. Revise generating source in work/; hash before/after, render anew; never patch binaries. Local records do not update cloud memory.

COURSE REFERENCES
Each assignment: read sources/Cole S - CONE 414 Course Reference.txt and sources/ files below, prefixed Cole S - :
- Concrete PDF Course References.txt
- Concrete PDF Text Evidence.txt
- Concrete PDF Reference Record.json
- Concrete Structures Course References.txt
- Concrete Structures Lecture Corpus.txt
- Concrete Structures Transcript Reference Record.json
- Concrete Lecture Visual Index.txt
- Concrete Lecture Visual Corpus.txt
- Concrete Lecture Visual Reference Record.json
- Concrete Lecture Visuals/ (screenshots)
Search indexes/corpora; inspect original PDF pages/crops and full-size screenshots. Cite PDF-ID with physical/printed pages; lectures/frames by CD-XX, frame ID and timestamp. Sampled frames omit steps; check video/context. ASR labels may misdescribe images. Class slides/appendix govern; assignment text/figures supply givens. Verify screenshots/annotations/prior answers; OCR/ASR are retrieval leads. Verify symbols/values against originals; log conflicts, preserve raw wording; never inherit example givens. Tables.pdf: canonical appendix. Read table/edition/timing cautions; ingestion certifies no math/table cells.

VERIFIED CALCULATIONS
Inspect all pages; solve requested problems; preserve numbering, verify givens/crops; never invent missing/obscured content. Check h/d, web/flange/slab geometry, offsets/spacing, support faces, spans/layers. Keep given d; derive missing d from cover/diameters/centroid. State consequential assumptions once. One verified record supplies values; full precision, round displays only. Check units/conversions. Add excluded self-weight without slab/beam overlap; apply class combinations to unfactored loads. Show formulas/substitutions/units.
Mixtures: absolute-volume/air/ratio checks. Cracking: rupture stress, gross inertia, M_cr, total/additional loads. Cracked sections: moduli, modular ratio, compression-depth equilibrium, inertia, concrete/steel stresses. Check force/moment equilibrium; distinguish elastic/ultimate analysis.

FLEXURE AND CONTINUITY
Apply class depth limits to actual span/continuity; minimum h differs from selection; depth tables do not prescribe width. Verify coefficient applicability/exterior restraint; show signed span/face equations M_u=+/-w_u*l_n^2/x. Coefficient curves define no exact functions/inflection points; never import end conditions.
Verify appendix strengths/grade/units/lookup rule; retain entries visibly. Check R=M_u/(phi*b*d^2), A_s,req=rho*b*d, provided bar areas. Calculate block depth,c,beta1,strain,yielding,phi,M_n,phi*M_n as requested; check minimum steel/limits/capacity.
Check cover/spacing/counts/layers/centroid; deduct both side allowances/all diameters. Keep feasible single layers; revise d for changed layers. T sections: flange limits/control, slab extensions, block/slab depth, flange-only or flange-plus-web equilibrium. Outermost need not be one-sided.

SHEAR, TORSION AND LOADING
Use class equations/phi, T-beam web width and total-leg A_v. Include self-weight; draw SFD; distinguish reaction from critical-section shear from support face. Declare missing support widths. Check minimum steel/spacing/section limits; round maximum spacing down, verify capacity. Preserve fit/strength failures mathematically.
Check torsion threshold/section adequacy before spacing. Distinguish A_cp,p_cp,A_oh,p_h,A_o. Cover to hoop outside: x1=b-2cover-d_st, y1=h-2cover-d_st. A_t: one leg; A_v: total shear legs. Declare missing shear/angle/yield assumptions. Closer hoops cannot fix geometry; show failure before enlargement; repeat checks. Original equations govern shortcuts. Hoop strength alone proves no cage/anchorage. Verify occupancy loading or retain input with conditional inequality/allowable-load limit.

THREE CONCURRENT REVIEWERS
Full solutions: share crops/data once; exactly three concurrent independent read-only agents: materials/elastic, flexure/floor systems, shear/torsion, adapted to problems. No nested/extra agents, reviewer edits or duplicate rendering. Reports: givens, equations/evidence, results, assumptions/failures. Primary calculates independently, reconciles conflicts, alone edits. Same three for final concurrent acceptance; evaluate all reports; never fabricate reviews. Small preference/ingestion: no delegation unless requested.

INSTALLED RESOURCES
Root: /Users/kindiffident/.codex/skills/personal-penmanship
Read SKILL.md and references/{rendering,model-card,structural-diagrams}.md. Retain model.json, glyph coverage/exclusions, diagram library/manifest/adapter. Seed 414 unless user changes it. No fonts/raster equations/retraining/unrequested persistence; extend tested workspace copies only. New samples need complete-contour labels/provenance; trace raster content.

FINISHED PAGES
Separate Letter pages; readable orientation; reflow, do not shrink. Start each problem once with standalone Q1., Q2., etc. Name first page only. Omit questions, descriptive/subheadings, continuation/course/assignment headings, repeated headers, page numbers/progression marks.
Show givens/definitions/assumptions once, math/substitutions/units, diagram labels/results. Verification/scope reminders/repetition/unfinished-status/production/source audits stay internal. Omit: Table A11, NA, Threshold Trial, One row needs, use, adequate in flexure at, CONE 414, Load set, Assume inside exposure, aggregate. Match short exclusions as whole words. Retain required math, assumptions/failures via symbols/inequalities; never hide conditionality.

DIAGRAMS AND ANSWER OUTLINES
Calculate geometry first; scale uniformly. Equal spans: equal widths; correct supports/contact points, load-arrow coverage/spacing. Elastic stress is triangular, ultimate blocks rectangular; strain branches pass through c. Uniform-load moment/shear curves follow governing functions.
Separate contours, letters, dimensions, equations/bar labels. Letters: 6 pt from supports, outside lobes; unrelated text/symbols/curves: 4 pt apart. Standalone + and - in their moment regions, 4 pt from contours; retain signed equations/face associations. Fit boxes to answer contours: 9–10 pt horizontal, 6–7 pt vertical padding, joined corners, 0.8–1.0 pt outlines, 8 pt exterior clearance. Place after supporting math, not fixed footers. Reflow, do not shrink required text.

ACCEPTANCE
No question marks/semicolons on pages. Periods only in decimals, authorized abbreviations and exact standalone Qn. once per actual problem. Validator exceptions: workspace copies, preserve other checks. Export exact visible text; no missing glyphs/parse errors. Validate units/values/geometry, glyph/curve collisions, signs/box containment. Render all final pages; inspect full pages/readable crops; fix failures, recheck delivery. Audits stay internal. Remove identifying Subject/Producer/Creator/Author/Creation Date/Modification Date/XMP, comments, attachments/hidden fields. Hash outputs/sources. Report paths, completed problems, three reconciled reports, seed, verification, consequential assumptions/limits. Completion requires artifact evidence.
